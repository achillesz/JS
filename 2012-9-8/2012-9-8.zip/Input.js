function Input(id)
{
	this.obj=document.getElementById(id);
}

Input.prototype.setText=function (str)
{
	this.obj.value=str;
};