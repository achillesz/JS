function Div(id)
{
	this.obj=document.getElementById(id);
}

Div.prototype.setText=function (str)
{
	this.obj.innerHTML=str;
};