function User(name)
{
	this.name=name;
}

User.showHello=function ()
{
	alert('你好啊');
};

User.prototype.showName=function ()
{
	alert(this.name);
};