function Regexp()
{
	
}

Regexp.checkEmail=function (str)
{
	return /^\w+@[a-z0-9\-]+\.[a-z]{2,10}$/.test(str);
};

//0-9
Regexp.checkPassword=function (str)
{
	var num=0;
	
	if(str.length>6)num+=3;
	if(str.length>18)num+=3;
	if(/[a-z]/.test(str))num+=2;
	if(/[0-9]/.test(str))num+=2;
	
	return num;
};

Regexp.checkNull=function (str)
{
	return /^\s+$/.test(str);
};

Regexp.checkQQ=function (str)
{
	return /^[1-9]\d{4, 10}$/.test(str);
};