function AJ(type)
{
	this.type=type;
}

AJ.prototype.get=function (url, data, fn)
{
	if(this.type=='ajax')
	{
		var str=url+json2url(data);
		
		ajax(str, function (str){
			var json=eval('('+str+')');
			
			fn(json);
		});
	}
	else if(this.type=='jsonp')
	{
		jsonp(url, data, fn);
	}
};