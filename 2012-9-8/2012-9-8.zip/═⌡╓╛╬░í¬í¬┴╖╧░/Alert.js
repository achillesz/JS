function Alert(str)
{
	MyAlert.call(this,"",str);
}

extend(MyAlert,Alert);

Alert.prototype._create = function()
{
	var _this = this;
	MyAlert.prototype._create.call(this);
	
	var oDiv = this.div.getElementsByTagName("div")[0];
	oDiv.innerHTML = "<input type='button' value = '确定' />";
	
	var oBtn = oDiv.getElementsByTagName("input")[0];
	
	oBtn.onclick = function()
	{
		_this.hide();
	}
}

var _alert = window.alert;
alert = function(msg)
{
	var oA = new Alert(msg);
	oA.show();
}
