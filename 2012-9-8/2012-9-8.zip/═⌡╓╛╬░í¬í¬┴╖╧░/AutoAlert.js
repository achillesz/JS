function AutoAlert(msg,time)
{
	Alert.call(this,msg);
	if(!time)time = 5;
	this.time = time;
}
extend(Alert,AutoAlert);

AutoAlert.prototype._create = function()
{
	Alert.prototype._create.call(this);
	//Alert.prototype._create();
	//this._create();
}

AutoAlert.prototype.show = function()
{
	Alert.prototype.show.call(this);
	
	var _this = this;
	var iRemain = this.time;
	
	function tick(){
		
		iRemain--;
		_this.div.getElementsByTagName('input')[0].value = "确定("+iRemain+")";
		if(iRemain ==0)
		{
			_this.hide();
		}
	}
	
	var timer = setInterval(tick,1000);
	tick();
	
}