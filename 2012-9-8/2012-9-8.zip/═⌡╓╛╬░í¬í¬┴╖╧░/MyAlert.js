function MyAlert(title,content)
{
	this.title = title;
	this.content = content;
	this._create();
}

MyAlert.prototype ={
	
	_create: function(){
		var oDiv = document.createElement("div");
		oDiv.innerHTML = format("<h2>{title}</h2><p>{content}</p><div></div>",{title:this.title,content:this.content});
		oDiv.className = "myAlert";
		document.body.appendChild(oDiv);
		
		var oBack = document.createElement("div");
		oBack.className = "myAlert_back";
		document.body.appendChild(oBack);
		
		this.div = oDiv;
		this.oback = oBack;
		
		var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
		oDiv.style.top = scrollTop+(document.documentElement.clientHeight-oDiv.offsetHeight)/2 + "px";
	},
	show: function(){
		
		this.div.style.display = "block";
		this.oback.style.display = "block";
	},
	hide: function(){
		
		this.div.style.display = "none";
		this.oback.style.display = "none";
	}
	
}