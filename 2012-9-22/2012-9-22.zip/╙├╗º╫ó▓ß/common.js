function addUser(user, pass)
{
	//reg: [{user: 'blue', pass: '123456'},....]
	
	if(localStorage['reg'])
	{
		//原来有
		var arr=eval(localStorage['reg']);
		arr.push({user: user, pass: pass});
		
		localStorage['reg']=JSON.stringify(arr);
	}
	else
	{
		//原来没有
		var arr=[];
		arr.push({user: user, pass: pass});
		
		localStorage['reg']=JSON.stringify(arr);
	}
}

function getUsers()
{
	if(localStorage['reg'])
	{
		return eval(localStorage['reg']);
	}
	else
	{
		return [];
	}
}

function delUser(user)
{
	if(localStorage['reg'])
	{
		//原来有
		var arr=eval(localStorage['reg']);
		
		for(var i=0;i<arr.length;i++)
		{
			if(arr[i].user==user)
			{
				arr.splice(i, 1);
			}
		}
		
		localStorage['reg']=JSON.stringify(arr);
	}
}

