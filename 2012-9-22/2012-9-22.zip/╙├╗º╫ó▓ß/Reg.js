//用于用户注册
function Reg()
{
	var _this=this;
	
	this.aListener=[];
	var oTxt1=document.getElementById('user');
	var oTxt2=document.getElementById('pass');
	var oBtn=document.getElementById('btn1');
	
	oBtn.onclick=function ()
	{
		//1.注册一个用户
		addUser(oTxt1.value, oTxt2.value);
		oTxt1.value='';
		oTxt2.value='';
		
		//2.通知"别人"
		for(var i=0;i<_this.aListener.length;i++)
		{
			_this.aListener[i]();
		}
		
		alert('注册成功');
	};
}

Reg.prototype.addListener=function (fn)
{
	this.aListener.push(fn);
};