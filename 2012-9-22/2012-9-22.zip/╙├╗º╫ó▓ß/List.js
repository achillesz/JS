//用户列表

function List(reg)
{
	var _this=this;
	
	this.aListener=[];
	this.oUl=document.getElementById('ul1');
	
	reg.addListener(function (){
		_this.loadData();
	});
	
	this.addListener(function (){
		_this.loadData();
	});
}

List.prototype.loadData=function ()
{
	this.oUl.innerHTML='';
	
	var _this=this;
	var arr=getUsers();
	
	for(var i=0;i<arr.length;i++)
	{
		var oLi=document.createElement('li');
		
		oLi.innerHTML='用户名：'+arr[i].user+' <em>'+arr[i].pass+'</em><a href="javascript:;">删除</a>';
		
		oLi.getElementsByTagName('a')[0].user=arr[i].user;
		oLi.getElementsByTagName('a')[0].onclick=function ()
		{
			//删除
			delUser(this.user);
			
			//通知
			for(var i=0;i<_this.aListener.length;i++)
			{
				_this.aListener[i]();
			}
		};
		
		this.oUl.appendChild(oLi);
	}
};

List.prototype.addListener=function (fn)
{
	this.aListener.push(fn);
};