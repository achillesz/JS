//最新注册的一个用户
function LastReg(reg, list)
{
	var _this=this;
	this.oDiv=document.getElementById('last');
	
	reg.addListener(function (){
		_this.loadData();
	});
	
	list.addListener(function (){
		_this.loadData();
	});
}

LastReg.prototype.loadData=function ()
{
	var arr=getUsers();
	
	if(arr.length>0)
	{
		this.oDiv.innerHTML='最新注册：'+arr[arr.length-1].user;
	}
};