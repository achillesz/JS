function Select(id)
{
	var _this=this;
	this.sel=document.getElementById(id);
	
	this.sel.onchange=function ()
	{
		for(var i=0;i<_this.arr_listener.length;i++)
		{
			_this.arr_listener[i](this.value);
		}
	};
	
	this.arr_listener=[];	//监听队列
}

Select.prototype.addListener=function (fn)
{
	this.arr_listener.push(fn);
};

