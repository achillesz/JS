function Fee(id, oSel)
{
	var _this=this;
	this.div=document.getElementById(id).getElementsByTagName('div')[0];
	
	oSel.addListener(function (n){
		_this.setFee(n);
	});
}

Fee.prototype.setFee=function (n)
{
	if(n==1)
	{
		this.div.innerHTML='资费1';
	}
	else if(n==2)
	{
		this.div.innerHTML='资费2';
	}
}