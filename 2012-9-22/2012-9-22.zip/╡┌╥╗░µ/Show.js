function Show(id)
{
	this.div=document.getElementById(id).getElementsByTagName('div')[0];
}

Show.prototype.setShow=function (n)
{
	if(n==1)
	{
		this.div.innerHTML='详单1';
	}
	else if(n==2)
	{
		this.div.innerHTML='详单2';
	}
};