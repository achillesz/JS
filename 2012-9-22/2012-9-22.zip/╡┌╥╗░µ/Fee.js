function Fee(id)
{
	this.div=document.getElementById(id).getElementsByTagName('div')[0];
}

Fee.prototype.setFee=function (n)
{
	if(n==1)
	{
		this.div.innerHTML='资费1';
	}
	else if(n==2)
	{
		this.div.innerHTML='资费2';
	}
}