function Package(id)
{
	this.div=document.getElementById(id).getElementsByTagName('div')[0];
}

Package.prototype.setPack=function (n)
{
	if(n==1)
	{
		this.div.innerHTML='相关套餐1';
	}
	else if(n==2)
	{
		this.div.innerHTML='相关套餐2';
	}
};