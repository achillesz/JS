function Select(id)
{
	this.sel=document.getElementById(id);
	
	var fee=new Fee('div_fee');
	var pack=new Package('div_package');
	var show=new Show('div_show');
	
	this.sel.onchange=function ()
	{
		fee.setFee(this.value);
		pack.setPack(this.value);
		show.setShow(this.value);
	}
}

